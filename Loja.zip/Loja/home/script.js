window.addEventListener('DOMContentLoaded', () => {
  const userLogado = JSON.parse(localStorage.getItem('userLogado'));
  const logadoElement = document.getElementById('logado');
  const loginMenuItem = document.querySelector('.menu li:last-child a');
  const loginMenuItemHamburger = document.querySelector('#hamburger-last-child')

  if (userLogado) {
    logadoElement.innerHTML = `Olá, ${userLogado.nome}`;
    loginMenuItem.innerText = 'Sair';
    loginMenuItem.href = '#';
    loginMenuItem.addEventListener('click', deslogarUsuario);

    loginMenuItemHamburger.innerText = 'Sair';
    loginMenuItemHamburger.href = '#';
    loginMenuItemHamburger.addEventListener('click', deslogarUsuario);
  } else {
    logadoElement.innerHTML = '';
    loginMenuItem.innerText = 'Entrar ou Cadastrar';
    loginMenuItem.href = '/login/login.html';
    loginMenuItem.removeEventListener('click', deslogarUsuario);

    loginMenuItemHamburger.innerText = 'Entrar ou Cadastrar';
    loginMenuItemHamburger.href = '/login/login.html';
    loginMenuItemHamburger.removeEventListener('click', deslogarUsuario);
  }
});

function deslogarUsuario() {
  localStorage.removeItem('userLogado');
  window.location.reload();
}

const hamburger = document.querySelector('.hamburger');
const menu = document.querySelector('.menu');

hamburger.addEventListener('click', () => {
  menu.classList.toggle('open');
  hamburger.classList.toggle('active');
});

document.querySelectorAll('.menu a').forEach(link => {
  link.addEventListener('click', () => {
    menu.classList.remove('open');
    hamburger.classList.remove('active');
  });
});

function toggleMenu() {
  const menuMobile = document.getElementById('menu-mobile');
  menuMobile.style.display = menuMobile.style.display === 'block' ? 'none' : 'block';
}