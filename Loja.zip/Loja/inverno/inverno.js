window.addEventListener('DOMContentLoaded', () => {
  const userLogado = JSON.parse(localStorage.getItem('userLogado'));
  const logadoElement = document.getElementById('logado');
  const loginMenuItem = document.querySelector('.menu li:last-child a');
  const loginMenuItemHamburger = document.querySelector('#hamburger-last-child')

  if (userLogado) {
    logadoElement.innerHTML = `Olá, ${userLogado.nome}`;
    loginMenuItem.innerText = 'Sair';
    loginMenuItem.href = '#';
    loginMenuItem.addEventListener('click', deslogarUsuario);

    loginMenuItemHamburger.innerText = 'Sair';
    loginMenuItemHamburger.href = '#';
    loginMenuItemHamburger.addEventListener('click', deslogarUsuario);
  } else {
    logadoElement.innerHTML = '';
    loginMenuItem.innerText = 'Entrar ou Cadastrar';
    loginMenuItem.href = '/login/login.html';
    loginMenuItem.removeEventListener('click', deslogarUsuario);

    loginMenuItemHamburger.innerText = 'Entrar ou Cadastrar';
    loginMenuItemHamburger.href = '/login/login.html';
    loginMenuItemHamburger.removeEventListener('click', deslogarUsuario);
  }
});

function deslogarUsuario() {
  localStorage.removeItem('userLogado');
  window.location.reload();
}

const hamburger = document.querySelector('.hamburger');
const menu = document.querySelector('.menu');

hamburger.addEventListener('click', () => {
  menu.classList.toggle('open');
});

document.querySelectorAll('.menu a').forEach(link => {
  link.addEventListener('click', () => {
    menu.classList.remove('open');
  });
});

document.addEventListener('DOMContentLoaded', function() {
    const collectionCards = document.querySelectorAll('.collection-card');
    
    function checkVisibility() {
      collectionCards.forEach(card => {
        const rect = card.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          card.classList.add('visible');
        } else {
          card.classList.remove('visible');
        }
      });
    }
  
    collectionCards.forEach(card => {
      card.classList.add('invisible');
    });
  
    window.addEventListener('scroll', checkVisibility);
    checkVisibility();
  });
  
  const style = document.createElement('style');
  style.innerHTML = `
    .invisible {
      opacity: 0;
      transform: translateY(20px);
      transition: opacity 0.6s ease-out, transform 0.6s ease-out;
    }
    
    .visible {
      opacity: 1;
      transform: translateY(0);
    }
  `;
  document.head.appendChild(style);

  function toggleMenu() {
    const menu = document.querySelector('.menu-mobile');
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}
