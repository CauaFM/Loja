function togglePasswordVisibility(buttonId, passwordFieldId) {
    document.getElementById(buttonId)?.addEventListener('click', function () {
      const passwordField = document.getElementById(passwordFieldId);
      const type = passwordField.type === 'password' ? 'text' : 'password';
      passwordField.type = type;
      
      this.classList.toggle('bi-eye-slash');
    });
  }
  
  togglePasswordVisibility('toggleNewPassword', 'newPassword');
  togglePasswordVisibility('toggleConfirmPassword', 'confirmPassword');
  
  document.getElementById('registerForm')?.addEventListener('submit', function (event) {
    event.preventDefault(); 
  
    const username = document.getElementById('newUsername').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
  
    if (password !== confirmPassword) {
      document.getElementById('errorMessage')?.classList.remove('d-none');
      return;
    }
  
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const existingUser = users.find(user => user.email === email);
  
    if (existingUser) {
      document.getElementById('errorMessage')?.classList.remove('d-none');
      return;
    }
  
    const newUser = { username, email, password };
  
    users.push(newUser);
  
    localStorage.setItem('users', JSON.stringify(users));
  
    document.getElementById('registerForm').reset();
  
    alert('Cadastro realizado com sucesso!');
  
    window.location.href = '/login/login.html';
  });
  